# XMiR-Patcher
Firmware patcher for Xiaomi routers


## Usage

### Windows

* Run `run.bat`

### Linux / Mac OS

* Install python 3.8, openssl
* Run `run.sh`

## Donations

<img src=https://cdn-icons-png.flaticon.com/16/14446/14446252.png alt="USDT" style="vertical-align: middle;"/> USDT (ethereum network)
```
0x840E78D3E47A7ed4987bc36b4A4f0C5240bd7DE8
```
