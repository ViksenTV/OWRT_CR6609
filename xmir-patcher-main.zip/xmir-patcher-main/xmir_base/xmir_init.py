import os
import sys

#print("xmir_init")

xmir_base_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, xmir_base_dir)

root_dir = os.path.dirname(xmir_base_dir)
sys.path.insert(0, root_dir)

#import gateway

